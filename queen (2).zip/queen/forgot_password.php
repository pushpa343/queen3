<?php
require 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        $error = 'Please enter your email address';
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database
            $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
            $stmt->execute([$token, $expires, $email]);
            
            // Send reset email
            $reset_link = "http://yourdomain.com/reset_password.php?token=$token";
            
            require 'PHPMailer/PHPMailerAutoload.php';
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = SMTP_HOST;
            $mail->Port = SMTP_PORT;
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USER;
            $mail->Password = SMTP_PASS;
            $mail->SMTPSecure = 'tls';
            
            $mail->setFrom(FROM_EMAIL, FROM_NAME);
            $mail->addAddress($email);
            $mail->isHTML(true);
            
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "
                <h2>Password Reset</h2>
                <p>We received a request to reset your password. Click the link below to reset it:</p>
                <p><a href='$reset_link'>$reset_link</a></p>
                <p>This link will expire in 1 hour.</p>
                <p>If you didn't request this, please ignore this email.</p>
            ";
            
            if($mail->send()) {
                $success = 'Password reset link has been sent to your email';
            } else {
                $error = 'Failed to send reset email. Please try again.';
            }
        } else {
            $error = 'Email not found in our system';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - New Queen Tailor</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <div class="text-center mb-8">
                <img src="images/logo/logo without bg.png" alt="Logo" class="h-20 mx-auto mb-4">
                <h1 class="text-2xl font-bold text-purple-800">Reset Your Password</h1>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="forgot_password.php">
                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Enter your email</label>
                    <input class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" 
                           type="email" id="email" name="email" required>
                </div>
                
                <button type="submit" class="w-full bg-purple-700 text-white py-2 px-4 rounded-lg hover:bg-purple-800 transition">
                    Send Reset Link
                </button>
            </form>
            
            <div class="mt-4 text-center">
                <p class="text-gray-600">Remember your password? <a href="login.php" class="text-purple-700 hover:underline">Log in</a></p>
            </div>
        </div>
    </div>
</body>
</html>