<?php
require 'config.php';

if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - New Queen Tailor</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <nav class="flex items-center justify-between px-6 py-4 shadow-md bg-white relative z-50">
        <div class="flex items-center space-x-3">
            <img src="images/logo/logo without bg.png" alt="New Queen Tailor Logo" class="h-20 w-auto" />
            <span class="text-2xl font-extrabold text-[#9D8140] tracking-wide">NEW QUEEN TAILOR</span>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-purple-900">Welcome, <?php echo htmlspecialchars($user_name); ?></span>
            <a href="logout.php" class="px-5 py-2 rounded-lg bg-purple-600 text-white font-semibold hover:bg-purple-700 transition duration-200 shadow-md">Logout</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-purple-800 mb-8">Your Dashboard</h1>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Dashboard Cards -->
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-purple-700 mb-4">Your Orders</h2>
                <p class="text-gray-600">View and track your current orders</p>
                <a href="orders.php" class="mt-4 inline-block text-purple-600 hover:underline">View Orders →</a>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-purple-700 mb-4">Book New Service</h2>
                <p class="text-gray-600">Schedule a new tailoring service</p>
                <a href="book.php" class="mt-4 inline-block text-purple-600 hover:underline">Book Now →</a>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-purple-700 mb-4">Account Settings</h2>
                <p class="text-gray-600">Update your profile information</p>
                <a href="profile.php" class="mt-4 inline-block text-purple-600 hover:underline">Edit Profile →</a>
            </div>
        </div>
    </div>
</body>
</html>