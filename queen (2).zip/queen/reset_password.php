<?php
require 'config.php';

$error = '';
$success = '';
$valid_token = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    // Check if token is valid and not expired
    $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->execute([$token]);
    
    if ($stmt->rowCount() > 0) {
        $valid_token = true;
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (empty($password) || empty($confirm_password)) {
                $error = 'Both password fields are required';
            } elseif ($password !== $confirm_password) {
                $error = 'Passwords do not match';
            } elseif (strlen($password) < 6) {
                $error = 'Password must be at least 6 characters';
            } else {
                // Update password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?");
                $stmt->execute([$hashed_password, $token]);
                
                $success = 'Password has been reset successfully. You can now <a href="login.php" class="text-purple-700 hover:underline">login</a> with your new password.';
            }
        }
    }
}

if (!$valid_token) {
    $error = 'Invalid or expired reset token';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - New Queen Tailor</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <div class="text-center mb-8">
                <img src="images/logo/logo without bg.png" alt="Logo" class="h-20 mx-auto mb-4">
                <h1 class="text-2xl font-bold text-purple-800">Reset Your Password</h1>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($valid_token): ?>
                <form method="POST" action="reset_password.php?token=<?php echo htmlspecialchars($_GET['token']); ?>">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="password">New Password</label>
                        <input class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" 
                               type="password" id="password" name="password" required>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="confirm_password">Confirm New Password</label>
                        <input class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" 
                               type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" class="w-full bg-purple-700 text-white py-2 px-4 rounded-lg hover:bg-purple-800 transition">
                        Reset Password
                    </button>
                </form>
            <?php endif; ?>
            
            <div class="mt-4 text-center">
                <p class="text-gray-600"><a href="login.php" class="text-purple-700 hover:underline">Back to login</a></p>
            </div>
        </div>
    </div>
</body>
</html>