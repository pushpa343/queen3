<?php
require 'config.php';

if (!isset($_SESSION['email']) || !isset($_SESSION['otp_sent'])) {
    header('Location: signup.php');
    exit();
}

$error = '';
$email = $_SESSION['email'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $otp = trim($_POST['otp']);
    
    if (empty($otp)) {
        $error = 'Please enter the OTP';
    } else {
        // Check if OTP is valid
        $stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE email = ? AND otp = ? AND expires_at > NOW()");
        $stmt->execute([$email, $otp]);
        
        if ($stmt->rowCount() > 0) {
            // Mark user as verified
            $stmt = $pdo->prepare("UPDATE users SET is_verified = 1 WHERE email = ?");
            $stmt->execute([$email]);
            
            // Clear OTP records
            $stmt = $pdo->prepare("DELETE FROM otp_verification WHERE email = ?");
            $stmt->execute([$email]);
            
            // Set session variables
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['logged_in'] = true;
            
            // Redirect to dashboard
            header('Location: dashboard.php');
            exit();
        } else {
            $error = 'Invalid or expired OTP';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - New Queen Tailor</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <div class="text-center mb-8">
                <img src="images/logo/logo without bg.png" alt="Logo" class="h-20 mx-auto mb-4">
                <h1 class="text-2xl font-bold text-purple-800">Verify Your Email</h1>
                <p class="text-gray-600 mt-2">We've sent a 6-digit OTP to <?php echo $email; ?></p>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="verify_otp.php">
                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="otp">Enter OTP</label>
                    <input class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" 
                           type="text" id="otp" name="otp" maxlength="6" required>
                </div>
                
                <button type="submit" class="w-full bg-purple-700 text-white py-2 px-4 rounded-lg hover:bg-purple-800 transition">
                    Verify & Continue
                </button>
            </form>
            
            <div class="mt-4 text-center">
                <p class="text-gray-600">Didn't receive OTP? <a href="resend_otp.php" class="text-purple-700 hover:underline">Resend</a></p>
            </div>
        </div>
    </div>
</body>
</html>