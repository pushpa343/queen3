<?php
require 'config.php';

if (!isset($_SESSION['email'])) {
    header('Location: signup.php');
    exit();
}

$email = $_SESSION['email'];

// Generate new OTP
$otp = rand(100000, 999999);

// Delete old OTPs
$stmt = $pdo->prepare("DELETE FROM otp_verification WHERE email = ?");
$stmt->execute([$email]);

// Store new OTP
$stmt = $pdo->prepare("INSERT INTO otp_verification (email, otp) VALUES (?, ?)");
$stmt->execute([$email, $otp]);

// Send OTP email
if (sendOTP($email, $otp)) {
    $_SESSION['otp_sent'] = true;
    header('Location: verify_otp.php');
    exit();
} else {
    $_SESSION['error'] = 'Failed to resend OTP. Please try again.';
    header('Location: signup.php');
    exit();
}
?>